# -*- coding: utf-8 -*-
from pyspark.sql import SparkSession
job = 'job'
spark = SparkSession.builder.appName(job) \
					.config("hive.exec.dynamic.partition", "true") \
					.config("hive.exec.dynamic.partition.mode", "nonstrict") \
					.enableHiveSupport() \
					.getOrCreate()
					
		

##write tables
hive_w= 'aplicacao.clienteaplicacao'
hive_w2= 'aplicacao.clientecontexto'
hive_w3= 'aplicacao.vendaplicacao'
hive_w4= 'aplicacao.produtoloja'
hive_w6= 'aplicacao.produtocontexto'
hive_w7='aplicacao.vendacontexto'

#prod aplicacao
##########################  CLIENTES  ##########################

## 01 NOVOS CLIENTES (APP)

print ('início do processo de monitoramento')

df_clientes_app = spark.sql('''
select datacadastro, count(cpf) as novosclientes, datacarga, current_date as data_exec
from (
select cpf, datacarga, max(cast(datacadastrocba as date)) as datacadastro
from aplicacao.carcadastro
where datacadastrocba > date_sub(current_date(), 30)
group by cpf, datacarga
union
select cpf, datacarga, max(cast(datacadastropfr as date)) as datacadastro
from aplicacao.carcadastro
where datacadastropfr > date_sub(current_date(), 30)
group by cpf, datacarga
union
select cpf, datacarga, max(cast(datacadastroext as date)) as datacadastro
from aplicacao.carcadastro
where datacadastroext > date_sub(current_date(), 30) 
group by cpf, datacarga) x

group by datacadastro, datacarga
order by datacadastro Desc

''')

print ('gravando tabela ' + hive_w)
## criar DDL da tabela resultante e solicitar a criação no ambiente.
## Consultar com Jessiane e\ou Felipe ajuste para insert ao inves do saveastabel
df_clientes_app.write.option("compression", "zlib").option("encoding", "UTF-8").mode("overwrite").format("orc").option("header", "false").insertInto(hive_w)


#print(df_clientes_app)


## 02 NOVOS CLIENTES (Context)
df_clientes_ctx = spark.sql('''
select datacadastro, count(cpfcnpj) as novosclientes, current_date as data_exec
from (
select cpfcnpj, max(cast(datacriacao as date)) as datacadastro
from context.cliente
where datacriacao > date_sub(current_date(), 30)
group by cpfcnpj) x

group by datacadastro
order by datacadastro desc

''')
print ('gravando tabela ' + hive_w2)
df_clientes_ctx.write.option("compression", "zlib").option("encoding", "UTF-8").mode("overwrite").format("orc").option("header", "false").insertInto(hive_w2)

#print(df_clientes_ctx)

##########################  VENDAS  ##########################

## 01 VENDAS POR DIA/BANDEIRA/ORIGEM

df_vendas_app = spark.sql('''
select origem, bandeira, max(cast(datapedido as date)) as datapedido, sum(qtdmercadoriaitem) as TotalItens, sum(valorliquido) as TotalLiquido, current_date as data_exec
from aplicacao.itempedido
where datapedido >= date_sub(current_date(), 30)
group by origem, bandeira, cast(datapedido as date)
order by datapedido desc


''')
print ('gravando tabela ' + hive_w3)
df_vendas_app.write.option("compression", "zlib").option("encoding", "UTF-8").mode("overwrite").format("orc").option("header", "false").insertInto(hive_w3)

#print(df_vendas_app)

## 02 VENDAS POR DIA/BANDEIRA/ORIGEM (Context):

df_vendas_ctx = spark.sql('''
select  b.origem, b.bandeira, MAX(cast(a.DATAPEDIDO as date)) as datapedido, sum(b.qtdmercadoriaitem) as TotalItens, sum(a.valorliquido) as TotalLiquido, current_date as data_exec
from context.pedido a, context.itempedido b
where a.chavepedido = b.chavepedido and a.DATAPEDIDO >= date_sub(current_date(), 30)
group by b.origem, b.bandeira, cast(a.datapedido as date)
order by datapedido desc

''')
print ('gravando tabela ' + hive_w7)
df_vendas_ctx.write.option("compression", "zlib").option("encoding", "UTF-8").mode("overwrite").format("orc").option("header", "false").insertInto(hive_w7)

#print(df_vendas_ctx)


## 03 Duplicados Context

df_prod_ctx = spark.sql('''
select origem, idsku, count(idsku) as duplicados, current_date as data_exec
from context.produto
group by idsku, origem
having count(idsku) > 1 and (origem = 'site' or origem = 'mkt')

''')
print ('gravando tabela ' + hive_w6)
df_prod_ctx.write.option("compression", "zlib").option("encoding", "UTF-8").mode("overwrite").format("orc").option("header", "false").insertInto(hive_w6)

#print(df_prod_ctx)

